import UIKit


// 1. 추상 클래스
class AbstractOperation {
    func operate(_ a: Double, _ b: Double) -> Double {
        return 0
    }
}
// 2. 연산 클래스
class AddOperation: AbstractOperation {
    override func operate(_ a: Double, _ b: Double) -> Double {
        return a + b
    }
}

class SubstractOperation: AbstractOperation {
    override func operate(_ a: Double, _ b: Double) -> Double {
        return a - b
    }
}

class MultiplyOperation: AbstractOperation {
    override func operate(_ a: Double, _ b: Double) -> Double {
        return a * b
    }
}

class DivideOperation: AbstractOperation {
    override func operate(_ a: Double, _ b: Double) -> Double {
        guard b != 0 else {
            print("정의되지 않음(결과: 0)")
            return 0
        }
        return a / b
    }
}

class RemainderOperation: AbstractOperation {
    override func operate(_ a: Double, _ b: Double) -> Double {
        let intA = Int(a)
        let intB = Int(b)
        
        if intB == 0 {
            print("정의되지 않음")
            return 0
        }
        return Double(intA % intB)
    }
}

class Calculator {
    var operation: AbstractOperation?
    
    func calculate(_ a: Double, _ b: Double) -> Double {
        return (operation?.operate(a, b)) ?? 0
    }
}

// 실행
    
func printResult(_ result: Double) {
    if result == Double(Int(result)) {
        print(Int(result))
    } else {
        print(result)
    }
}

let calculator = Calculator()

calculator.operation = AddOperation()
printResult(calculator.calculate(10, 5))  //15


calculator.operation = SubstractOperation()
printResult(calculator.calculate(10.5, 5))//5.5

calculator.operation = MultiplyOperation()
printResult(calculator.calculate(10.0, 5.2))//52
    
calculator.operation = DivideOperation()
printResult(calculator.calculate(100, 3.3))//30.303030303030305

calculator.operation = RemainderOperation()
printResult(calculator.calculate(10, 5))//0
printResult(calculator.calculate(5, 10))//5
printResult(calculator.calculate(100, 0))//정의되지 않음

        
        
       
  
